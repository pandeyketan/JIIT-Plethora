<?php 
include_once('DBConnection.php');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);  
?>

<!DOCTYPE html>
<html>
	<head>
		<title>JIIT Plethora </title>
		<link rel="shortcut icon" href="../images/Others/icon.png";>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn`.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">  
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>   <!-- Latest compiled JavaScript -->
		<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'  type='text/css'>   <!-- Google fonts -->
		<link rel="stylesheet" type="text/css" href="mainwepagestyle.css">
		<script >
			var index;
			function displayarea(index){ 
				$(".area").css("display","none");
				$(".area").each(function(i,element){
				if(index-1 == i)
					$(element).css("display","block");
				});
			}
			  
			$(document).ready(function() {
                showSlides();
				$(".recent-updates .column").each(function(index,element){
					if(index%2!=0)
						$(element).addClass("column1");
					else
					{
						$(element).css("float","left");
					}						
				});
				$(".recent-updates .column2").each(function(index,element){
					if(index%2!=0)
						$(element).addClass("column3");						
				});
                $(".events .content-overlay").click(function(){
                   $(".content-overlay").parent(".content-box").css("display","none"); 
                });
                $(".events .box-cover").click(function(){
                    $(".content-box").css("display","flex");
                    $(".content-box").css("animation","grow-box 2s ease-in-out");
                });
                $(".hubs .content-overlay").click(function(){
                   $(".content-overlay").parent(".content-box").css("display","none"); 
                });
                $(".hubs .box-cover").click(function(){
                    $(".content-box").css("display","flex");
                    $(".content-box").css("animation","grow-box 2s ease-in-out");
                });
			});
            var m=0;
			function move(m) {	
                
                var row = $(".upcoming-events .row");
                var w = parseInt(row.width())/3;
                var element = $(".upcoming-events .row .columns");
                var n = element.length;
                var leftpos= parseInt(row.scrollLeft());
                var newleftpos = leftpos + m*w;
                if((leftpos==0)&&(m==-1))
                    newleftpos = (n-3)*w;
                if(leftpos>(n-3)*w)
                    newleftpos=0;
                row.scrollLeft( newleftpos );
                
            }
             
            
            
			var slideIndex = 0;
			function plusSlides(n) {
			  var i;
			  slideIndex += n;
			  var x = document.getElementsByClassName("mySlides1");
			  if (slideIndex > x.length) {slideIndex = 1;}    
			  if (slideIndex < 1) {slideIndex = x.length;}
			  for (i = 0; i < x.length; i++) {
				 x[i].style.display = "none";  
			  }
			  slideIndex-=1;
			  x[slideIndex].style.display = "block"; 			  
			}
			
			function showSlides() {
				var i;
				var slides = document.getElementsByClassName("mySlides1");
				for (i = 0; i < slides.length; i++) {
				   slides[i].style.display = "none";  
				}
				slideIndex++;
				if (slideIndex > slides.length) {slideIndex = 1;}    
				slides[slideIndex-1].style.display = "block";  
				setTimeout(showSlides, 3000); // Change image every  3 seconds
			}
			
		</script>
	</head>
	<body>
	<div class="container-fluid">
		<div class="top-cover">
			<div class="Slides-container">
						<img class="mySlides1" src="../images/Others/image1.jpg" >
						<img class="mySlides1" src="../images/Others/image2.jpg">
						<img class="mySlides1" src="../images/Others/image3.jpg" >
						<img class="mySlides1" src="../images/Others/image4.jpg" >
						<img class="mySlides1" src="../images/Others/image5.jpg">
						<div class="myOverlay"></div>
						<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
						<a class="next" onclick="plusSlides(1)">&#10095;</a>
			</div>
			<div class="login">
				<button onclick="location.href='adminlogin.php'" type="button">Admin login</button>
				<button onclick="location.href='studentcoordinatorlogin.php'" type="button">Coordinator login</button>
			</div>
			<div class="center">
				<div class="center-text">
				<p id="line3">Welcome</p><hr>
				<p id="line1" >JIIT </p><p id="line2"> Plethora</p>
				
				</div>
			</div>
			<div class="nav-bar">
				<a class="clicktest" onclick="displayarea(1)" >Home<hr></a>
				<a class="clicktest" onclick="displayarea(2)" >Events<hr></a>
				<a class="clicktest" onclick="displayarea(3)" >Hubs<hr></a>
				<a class="clicktest" href="#contact-us">Contact Us<hr></a>
				<a class="clicktest" onclick="displayarea(4)">About<hr></a>	
			</div>
		</div>
		<div class=" recent-updates area" id="recent-updates">
				<div class="heading">
				<span>Recent Updates</span>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 1</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 2</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 3</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 4</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 5</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 6</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="row">
					<div class="column">
						<div class="pics">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<img class="mySlides" src="../images/Others/image2.jpg">
						<img class="mySlides" src="../images/Others/image3.jpg" >
						<img class="mySlides" src="../images/Others/image4.jpg" >
						<img class="mySlides" src="../images/Others/image5.jpg">
						</div>
						<div class="update-content">
						<p class="time-stamp">12:00&nbsp;&nbsp;&nbsp;&nbsp;4/12/2018</p>
						<div class="update-text">
                            <span>Upadte of HUB 7</span>
                        </div>
						</div>
					</div>
					<div class="column2"></div>
				</div>
				<div class="more">
					<div>&#10095 </div>
				</div>
		</div>
		
		<div class=" area events" id="events">
			<div class="heading">
				<span>Events</span>
			</div>
            <div class="content-box">
                <div class="content-overlay"></div>
                <div class="flex-container">
                    <?php 
                    $sql="select * from events where flag=1 order by events";
                    $data=mysqli_query($db,$sql);
                    $row=mysqli_fetch_array($data,MYSQLI_NUM);
                    echo'
					<div class="event-content">
                        <div class="pic-container">
                            <img class="pic" src="../images/Others/image1.jpg" >
                            <div class="box-cover">
                                <p>'.$row[0].'</p>
                                <hr>
                            </div>
                        </div>
                        <div class="about-content">
                        <div class="details1">
                            <h3>About The Event:</h3>
                            <hr>
                            <p class="text">'.$row[4].'</p>
                        </div>
                        <div class="details2">
                        <div class="key-details">
                            <h3>Key Details:</h3><br>
                            <h4>Start Date:</h4><span>'.$row[2].'</span><br>
                            <h4>End Date:</h4><span>'.$row[3].'</span><br>
                            <h4>Managing Hub:</h4><span>'.$row[1].'</span>
                        </div>
                        <div class="registration">
                            <h3>Register Here:</h3>
                            <p></p>
                            <input type="button" name="event-register" id="event-register" value="Register">
                        </div>
                        </div>
                        </div>
                    </div>
                    <div class="related-content">
                        <h4>Past Profile:</h4>
                        <hr>
                        <div class="galary-container">
                        <div class="moving-galary">
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image1.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image1.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image1.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image1.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image1.jpg" >
                            </div>
                        </div>
                        </div>
                    </div>
                       ';
                    
                    ?>
                    
                </div>
            </div>
            <div class="upcoming-events">
				<div class="sub-heading">
					<span>Upcoming Events</span>
				</div>
				<div class="row-container">
				    <a class="moveleft" onclick="move(-1)">&#10094;</a>
					<a class="moveright" onclick="move(1)">&#10095;</a>
					<div class="row">
                    <?php 
                    $sql="select * from events where flag=1 order by events";
                    $data=mysqli_query($db,$sql);
                    while($row=mysqli_fetch_array($data,MYSQLI_NUM))
                    {
                    echo'
					<div class="columns">
                        <img class="mySlides" src="../images/Others/image7.jpg" >
                        <form action="" method="get">
                        
						<div onclick="" type="submit" class="box-cover">
							<span>'.$row[0].'</span>
						</div>
                        </form>
					</div>';
                    }
                    ?>
					</div>
                    
				</div>
			</div>
			
			<div class="all-events">
				<div class="sub-heading">
					<span>All Events</span>
				</div>
                <div class="events-container">
					<?php 
                    $sql="select NAME,HUB from events";
                    $data=mysqli_query($db,$sql);
                    while($row=mysqli_fetch_array($data,MYSQLI_NUM))
                    {
                    echo '
                    <div class="box">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<div class="box-cover">
							<span>'.$row[0].'</span>
							<hr>
                            <span class="box-details">'.$row[1].'</span>
						</div>
					</div>';
                    }
					?>
					<div class="box load-more">
						<img class="mySlides" src="../images/Others/image1.jpg" >
						<div class="box-cover">
							<span> More &#10095</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="area hubs" id="hubs">
			<div class="content-box">
                <div class="content-overlay"></div>
                <div class="flex-container">
                    <?php 
                    $sql="select * from hub";
                    $data=mysqli_query($db,$sql);
                    $row=mysqli_fetch_array($data,MYSQLI_NUM);
                    echo'
					<div class="hub-content">
                        <div class="pic-container">
                            <img class="pic" src="../images/Others/image1.jpg" >
                            <div class="box-cover">
                                <p>'.$row[0].'</p>
                                <hr>
                            </div>
                        </div>
                        <div class="about-content">
                        <div class="details1">
                            <h3>About The HUB:</h3>
                            <hr>
                            <p class="text">'.$row[7].'</p>
                        </div>
                        <div class="details1">
                           <h3>HUB Details:</h3><hr>
                            <h4>Coordinating Faculty:</h4><span>'.$row[2].'</span><br>
                            <h4>Number of Members:</h4><span>'.$row[1].'</span><br>
                            <div class="icons-container">
                                <div class="icons">
                                    <a href="http://'.$row[4].'"><img class="contact-icons" src="../images/icons/fb1.png" ></a>
                                </div>
                                <div class="icons">
                                    <a href="http://'.$row[6].'"><img class="contact-icons" src="../images/icons/google1.png" ></a>
                                </div>
                                <div class="icons">
                                    <a href="http://'.$row[5].'"><img class="contact-icons" src="../images/icons/www5.png" ></a>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>  
                    
                    <div class="related-content">
                        <h4>Past Profile:</h4>
                        <hr>
                        <div class="galary-container">
                        <div class="moving-galary">
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            <div class="pic-container">
                                <img class="pic" src="../images/Others/image7.jpg" >
                            </div>
                            
                        </div>
                        </div>
                    </div>
                       ';
                    ?>
                </div>
            </div>
            <div class="heading">
			<span>Hubs</span>
			</div>
			<?php 
                    $sql="select count(name) from hub";
                    $count_table=mysqli_query($db,$sql);
                    $count = mysqli_fetch_array($count_table,MYSQLI_NUM);
            
                    $sql="select * from hub";
                    $i=0;
                    $data=mysqli_query($db,$sql);
                    while($row = mysqli_fetch_array($data,MYSQLI_NUM))
                    {
                        if($i%4==0)
                            echo'<div class="col-3">';
                        if($row[3]==NULL)
                        $photo="../images/Hubs/image11.jpg";
                        else
                            $photo=$row[3];
                    echo'
				    <div class="rows">
					<img class="back-pic" src="'.$photo.'" >
					<div class="box-cover">
						<span>'.$row[0].'</span>
						<hr>
					</div>
                    </div>';
                    if((($i+1)%4==0)||(($i+1)==$count[0]))
                        echo'</div>';
                    $i=$i+1;
                    }
                ?>
			
		</div>
		<div class="about area" id="About">
            <div class="heading">
                <span>About</span>
            </div>
            <div class="about-container">
                <h1>Objective of the Website:</h1>
                <p>This website is made as the DB&W mini-project by these Students. </p>
                <div class="admin-container">
                    <div class="row">
                        <div class="column">
                        <div class="skew-column"></div>
                        <div class="admin-details">
                            <div class="admin-photo">
                                <img class="pic" src="../images/Admin/himanshu2.jpg" >
                            </div>
                            <div class="admin-profile">
                                <p>Name:</p><span>Himanshu Saini</span><br>
                                <p>Enrollment Number:</p><span>17103254</span><br>
                                <p>Batch:</p><span>B6</span><br>
                                <p>Email:</p><span>--</span>
                            </div>
                        </div>
                        </div>
                        <div class="column">
                        <div class="skew-column"></div>
                        <div class="admin-details">
                            <div class="admin-photo">
                                <img class="pic" src="../images/Admin/ketan2.jpg" >
                            </div>
                            <div class="admin-profile">
                                <p>Name:</p><span>Ketan pandey</span><br>
                                <p>Enrollment Number:</p><span>17103237</span><br>
                                <p>Batch:</p><span>B6</span><br>
                                <p>Email:</p><span>--</span>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="column">
                        <div class="skew-column"></div>
                        <div class="admin-details">
                            <div class="admin-photo">
                                <img class="pic" src="../images/Admin/Gaurav2.jpg" >
                            </div>
                            <div class="admin-profile">
                                <p>Name:</p><span>Gaurav garg</span><br>
                                <p>Enrollment Number:</p><span>17103250</span><br>
                                <p>Batch:</p><span>B6</span><br>
                                <p>Email:</p><span>--</span>
                            </div>
                        </div>
                        </div>
                        <div class="column">
                        <div class="skew-column"></div>
                        <div class="admin-details">
                            <div class="admin-photo">
                                <img class="pic" src="../images/Admin/Rakshit%20Gangwar2.jpg" >
                            </div>
                            <div class="admin-profile">
                                <p>Name:</p><span>Rakshit Gangwar</span><br>
                                <p>Enrollment Number:</p><span>17103246</span><br>
                                <p>Batch:</p><span>B6</span><br>
                                <p>Email:</p><span>--</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="footer" id="contact-us">
			<div class="row">
				<div class="C-flex quick-links">
					<div class="footer-headings">
						<span>QUICK LINKS</span>
					</div>
					<hr>
					<div class="footer-headings-info">
					<ul id="links-list">
						<li><a href="http://www.jiit.ac.in" target="_blank">JIIT</a></li>
						<li><a href="https://webkiosk.jiit.ac.in/" >Web Kiosk</a></li>
						<li><a href="adminlogin.php" >Admin Login</a></li>
						<li><a href="studentcoordinatorlogin.php" >Coordinator Login</a></li>
					</ul>
					</div>					
				</div>
				<div class="v-hr"></div>
				<div class="C-flex">
					<div class="footer-headings">
						<span>NEWSLETTER</span>
					</div>
					<hr>
					<div class="footer-headings-info">
						<p>Get updates in one click</p>
						<form method="post" action="#">
                            <input type="text" id="email" name="emaill" placeholder="Your Email"><br>
                            <input type="number" id="enroll" name="enroll" placeholder="Enrollment Number"><br>
                            <input type="button" id="submit" value="Submit">
						</form>
					</div>
				</div>
                
				<div class="v-hr"></div>
				<div class="C-flex contact-details">
					<div class="footer-headings">
						<span>CONTACT DETAILS</span>
					</div>
					<hr>
					<div class="footer-headings-info">
					<p>E-mail:admin.jiitplethara@gmail.com<br>Contact:999999999</p>
					<div class="icons">
						<img class="contact-icons" src="../images/icons/fb1.png" >
					</div>
					<div class="icons">
						<img class="contact-icons" src="../images/icons/google1.png" >
					</div>
					<div class="icons">
						<img class="contact-icons" src="../images/icons/instagram2.png" >
					</div>
					</div>
				</div>
			</div>
		</div>
		</div>

	</body>
</html>
