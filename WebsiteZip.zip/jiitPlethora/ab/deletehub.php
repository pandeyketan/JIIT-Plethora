<html>
            <head>
                <title>
                Delete Hub</title>
            <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
    <div class="container-contact100">
		<div class="contact100-map" id="google_map" data-map-x="40.722047" data-map-y="-73.986422" data-scrollwhell="0" data-draggable="1"></div>

		<div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Select a hub to be deleted!
				</span>
			</div>
        
        <br>
        <form class="contact100-form validate-form" method="post" name="form" action="successdeletehub.php" onsubmit="delete()" >
<?php
include_once('DBConnection.php');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);  
$T="SELECT NAME FROM HUB";
$result=$con->query($T);
            if ($result->num_rows > 0) 
            {
    while($row = $result->fetch_assoc()) 
    {
//        echo"<br>";
           ?>
            <div class='wrap-input100 validate-input'>
            <input type='checkbox' name="check[]" value='<?php echo $row['NAME']; ?>'>
            <?php
        echo $row['NAME'];?>
				<span class='focus-input100'></span></div>
            <?php
            
    }
}
?>
            
        <div class="container-contact100-form-btn" >
					<input type="submit" value="submit" name="submit" align="center" class="contact100-form-btn" >
                </div>
        </form>
            
            
        </div>
        </div>
        <script>
            function delete()
            {
                <?php
               
                ?>
            }
        </script>
    </body>
    
</html>