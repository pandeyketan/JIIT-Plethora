<?php
include_once('DBConnection.php');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);  
$a1=$_POST["name"];
$a2=$_POST["email"];
$a3=$_POST["fblink"];
$a4=$_POST["site"];
$a6=$_POST["message"];
$a7=$_POST["noofsc"];
$a8=$_POST["tcname"];
$a9=$_POST["tcdept"];
$a10=$_POST["tcmail"];

$sql="select NAME from hub";
$result=mysqli_query($con,$sql);
$i=0;
while($row=mysqli_fetch_array($result,MYSQLI_NUM))
{
    if($row[0]==$a1)
        $i=1;
}

if($i==0)
{
    function GetImageExtension($imagetype)
     {
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return false;
       }
     }
if (!empty($_FILES["logo"]["name"])) {
    $file_name=$_FILES["logo"]["name"];
    $temp_name=$_FILES["logo"]["tmp_name"];
    $imgtype=$_FILES["logo"]["type"];
    $ext= GetImageExtension($imgtype);
    $imagename=date("d-m-Y")."-".time().$ext;
    $target_path = "../images/upload/".$imagename;
    if(move_uploaded_file($temp_name, $target_path)) {
        $X="INSERT INTO HUB VALUES('$a1',$a7,'$a8','$target_path','$a3','$a4','$a2','$a6')";
        mysqli_query($con,$X);
        
        $X="INSERT INTO FACULTY VALUES('$a8','$a1','$a9','$a10')";
        mysqli_query($con,$X);
    }
    else{
        exit("Error While uploading image on the server");
    }
}
    



?>
<html>
<head>
    <title>
        Admin Login! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="mainadmin.css">
    </head>
    <body>
    <div class="container-contact100">
        <div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Conratulations!
				</span>
                
                <span class="contact100-form-title-2">
					Hub successfully added!
				</span>

			</div>

		<div class="wrap-contact100">
			
        <form class="contact100-form validate-form" method="post" action="mainwebpage.php">
				

            <div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Continue to website
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
        </div>
        </div>
        </div>
    </body>
</html>
<?php
}
else{
    echo "HUB already present";
    echo"<a href='addhub.php'>Click to continue</a>";
}
?>