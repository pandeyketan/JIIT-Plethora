<html>
<head>
    <title>
    Admin Page!
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="C:/xampp/htdocs/formmmm/images/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="newadmin.css">
    </head>
    <body>

<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Close &times;</button>
  <a href="addhub.php" class="w3-bar-item w3-button">Add a HUB</a>
  <a href="deletehub.php" class="w3-bar-item w3-button">Delete a HUB</a>
  <a href="addevent.php" class="w3-bar-item w3-button">Add an event</a>
  <a href="deleteevent.php" class="w3-bar-item w3-button">Delete an event</a>
</div>

<div id="main">

<div class="w3-teal">
  
  <div class="w3-container">
      <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()" style="display: inline-block;"><span>&#9776 &nbsp; Welcome admin..</span></button>
    
  </div>
</div>
</div>
         <div id="t1"> </div>
         <img src="images/impressions.jpg" style="width:1550px;height:700px;" class="center">
        
        
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>
    </body>
</html>