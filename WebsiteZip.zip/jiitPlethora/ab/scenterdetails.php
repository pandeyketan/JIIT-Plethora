<html>
<head>
    <title>
        Student Coordinator Details form! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="C:/xampp/htdocs/formmmm/images/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
    <div class="container-contact100">
		<div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Brief Us!
				</span>

				<span class="contact100-form-title-2">
					Tell us more about yourself!
				</span>
			</div>

			<form class="contact100-form validate-form" method="post" action="successsc.php" name="form" onsubmit="return validation()">
				<div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Name&nbsp;&nbsp;:</span>
					<input class="input100" type="text" name="scname" placeholder="Enter your name">
					<span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input" data-validate = "Hub is required">
					<span class="label-input100">Hub:</span>
					<input class="input100" type="text" name="schub" placeholder="Enter your joined Hub">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Designation is required">
					<span class="label-input100">Designation:</span>
					<input class="input100" type="text" name="scdesignation" placeholder="Enter designation">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Branch is required">
					<span class="label-input100">Branch:</span>
					<input class="input100" type="text" name="scbranch" placeholder="Enter your branch">
					<span class="focus-input100"></span>
				</div>
                
                
                <div class="wrap-input100 validate-input" data-validate = "Valid phone number is required">
					<span class="label-input100">Mobile:</span>
					<input class="input100" type="number" name="scmobile" placeholder="Enter mobile number">
					<span class="focus-input100"></span>
				</div>
                
				<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
					<span class="label-input100">Email:</span>
					<input class="input100" type="email" name="scemail" placeholder="Enter email addess">
					<span class="focus-input100"></span>
                </div>       
                

                
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Submit
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
		</div>
	</div>
        <script type="text/javascript">
function validation()
{

if(document.form.scname.value=="")
{
alert("Please Enter Student Coordinator's Name");
document.form.scname.focus();
return false;
}
if(document.form.scemail.value=="")
{
alert("Please Enter Student Coordinator's email");
document.form.scemail.focus();
return false;
}
if(document.form.schub.value=="")
{
alert("Please Enter Student Coordinator's Hub");
document.form.schub.focus();
return false;
}
if(document.form.scbranch.value=="")
{
alert("Please Enter Student Coordinator's Branch");
document.form.scbranch.focus();
return false;
}
if(document.form.scmobile.value=="")
{
alert("Please Enter Student Coordinator's Mobile no");
document.form.scmobile.focus();
return false;
}  
    if(document.form.scdesignation.value=="")
{
alert("Please Enter Student Coordinator's Designation");
document.form.scdesignation.focus();
return false;
}    
    
}
</script>
    </body>
</html>