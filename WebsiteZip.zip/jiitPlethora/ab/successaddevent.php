<?php
include_once('DBConnection.php');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE); 
$a1=$_POST["name"];
$a2=$_POST["startdate"];
$a3=$_POST["enddate"];
$a4=$_POST["detail"];
$a5=$_POST["hub"];
$a6=$_POST["check"];

$sql="select NAME from hub";
$result=mysqli_query($con,$sql);
$i=0;
while($row=mysqli_fetch_array($result,MYSQLI_NUM))
{
    if($row[0]==$a5)
        $i=1;
}
if($i==1)
{
$X="INSERT INTO EVENTS VALUES('$a1','$a5','$a2','$a3','$a4',$a6)";
mysqli_query($con,$X);


?>
<html>
<head>
    <title>
        Event Added! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="C:/xampp/htdocs/formmmm/images/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="mainadmin.css">
    </head>
    <body>
    <div class="container-contact100">
        <div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Conratulations!
				</span>
                
                <span class="contact100-form-title-2">
					Event successfully added!
				</span>

			</div>

		<div class="wrap-contact100">
			
        <form class="contact100-form validate-form" method="post" action="mainwebpage.php">
				

            <div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Continue to website
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
        </div>
        </div>
        </div>
    </body>
</html>
<?php
}
else{
    echo "Event cannot be added as the HUB not present";
    echo"<a href='addevent.php'>Click to continue</a>";
}
?>