<?php
include_once('DBConnection.php');
$con= mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);  

$checkBox = $_POST['check'];
if(sizeof($checkBox)==0)
{
    echo "Select the hubs";
    header("location:deletehub.php");
}
else
{
for($i=0; $i<sizeof($checkBox); $i++)
{
$T="DELETE FROM HUB WHERE NAME='$checkBox[$i]'";
mysqli_query($con,$T);
}
?>
<html>
    <head>
    <title>
        Success Page
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="mainadmin.css">
    </head>
    <body>
    <div class="container-contact100">
        <div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Conratulations!
				</span>
                
                <span class="contact100-form-title-2">
					Hub successfully deleted!
				</span>

			</div>

		<div class="wrap-contact100">
			
        <form class="contact100-form validate-form" method="post" action="mainwebpage.php">
				

            <div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Continue to website
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
        </div>
        </div>
        </div>
    </body>
</html>
<?php
}
?>