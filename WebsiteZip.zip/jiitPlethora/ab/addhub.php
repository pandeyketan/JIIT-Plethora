<html>
<head>
    <title>
        Hub Details form! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="C:/xampp/htdocs/formmmm/images/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
    <div class="container-contact100">
		<div class="contact100-map" id="google_map" data-map-x="40.722047" data-map-y="-73.986422" data-scrollwhell="0" data-draggable="1"></div>

		<div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Have a great start!
				</span>

				<span class="contact100-form-title-2">
					Tell us more about your hub!
				</span>
			</div>

			<form class="contact100-form validate-form" name="form" method="post" action="successaddhub.php" enctype="multipart/form-data" onsubmit="return validation()">
				<div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Hub Name&nbsp;&nbsp;:</span>
					<input class="input100" type="text" name="name" placeholder="Enter Hub name">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
					<span class="label-input100">Hub Email:</span>
					<input class="input100" type="email" name="email" placeholder="Enter email addess">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
					<span class="label-input100">Hub Fb link:</span>
					<input class="input100" type="text" name="fblink" placeholder="Enter Hub's fb link">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
					<span class="label-input100">Hub Site link:</span>
					<input class="input100" type="text" name="site" placeholder="Enter website link">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Message is required">
					<span class="label-input100">*Hub logo:</span>
					<input name="logo" type="file">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Message is required">
					<span class="label-input100">About your hub:</span>
					<textarea class="input100" name="message" placeholder="Enter Hub Details..."></textarea>
					<span class="focus-input100"></span>
				</div>
                
                <p style="margin-left: -180px; font-size: 20px;
    border-bottom-style: inset;
    border-bottom-left-radius: 15px;
    border-bottom-right-radius: 15px; ">Teacher coordinator details:</p><br><br>
                <div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Name:</span>
					<input class="input100" type="text" name="tcname" placeholder="Enter teacher coordinator's name">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate="Email is required">
					<span class="label-input100">E-mail:</span>
					<input class="input100" type="email" name="tcmail" placeholder="Enter teacher coordinator's email">
					<span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input" data-validate="Department is required">
					<span class="label-input100">Department:</span>
					<input class="input100" type="text" name="tcdept" placeholder="Enter teacher coordinator's department">
					<span class="focus-input100"></span>
				</div>
                
                <p style="margin-left: -180px; font-size: 20px;
    border-bottom-style: inset;
    border-bottom-left-radius: 15px;
    border-bottom-right-radius: 15px; ">Student coordinator details:</p><br><br>
                
                <div class="wrap-input100 validate-input" data-validate="Department is required">
					<span class="label-input100">No. of student coordinators:</span>
					<input class="input100" type="number" name="noofsc" placeholder="How many student coordinators does your hub has..?">
					<span class="focus-input100"></span>
				</div>
               

                
				<div class="container-contact100-form-btn">
					<input type="submit" value="Submit" class="contact100-form-btn">
                </div>
					
				
			</form>
		</div>
	</div>
<script type="text/javascript">
function validation()
{

if(document.form.name.value=="")
{
alert("Please Enter Hub's Name");
document.form.name.focus();
return false;
}
if(document.form.email.value=="")
{
alert("Please Enter Hub's ofiicial email");
document.form.email.focus();
return false;
}
if(document.form.tcname.value=="")
{
alert("Please Enter Teacher Coordinator's Name");
document.form.tcname.focus();
return false;
}
if(document.form.tcmail.value=="")
{
alert("Please Enter Teacher Coordinator's email");
document.form.tcmail.focus();
return false;
}
if(document.form.tcdept.value=="")
{
alert("Please Enter Teacher Coordinator's Department");
document.form.tcmail.focus();
return false;
}    
    
}
</script>
    </body>
</html>