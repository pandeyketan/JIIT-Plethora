<?php
include_once('DBConnection.php');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE); 
if(!$con)
{
    die("not connected".mysqli_error());
}
echo "connection established<br>";


$x="CREATE TABLE HUB(NAME VARCHAR(250),MEMBER INT,FACULTY VARCHAR(250),LOGO VARCHAR(250) ,FB VARCHAR(250),SITE VARCHAR(250),MAIL VARCHAR(250),ABOUT VARCHAR(250),PRIMARY KEY(NAME))";
if(!mysqli_query($con,$x))
die("wow1".mysqli_error($con));

$x="CREATE TABLE PERSON(NAME VARCHAR(25),HUB VARCHAR(250),DESIGNATION VARCHAR(25),BRANCH VARCHAR(25),PHONENO BIGINT, EMAIL VARCHAR(50),PRIMARY KEY (NAME), FOREIGN KEY (HUB) REFERENCES HUB(NAME))";
if(!mysqli_query($con,$x))
die("wow2".mysqli_error($con));


$x="CREATE TABLE EVENTS(NAME VARCHAR(25),HUB VARCHAR(250),EVENTS DATE,EVENTE DATE,DETAILS VARCHAR(255),FLAG BOOL,PRIMARY KEY (NAME,EVENTS,HUB),FOREIGN KEY (HUB) REFERENCES HUB(NAME))";
if(!mysqli_query($con,$x))
die("wow3".mysqli_error($con));

$x="CREATE TABLE FACULTY(NAME VARCHAR(25),HUB VARCHAR(250),DEP VARCHAR(25),EMAIL VARCHAR(25),FOREIGN KEY (HUB) REFERENCES HUB(NAME))";
if(!mysqli_query($con,$x))
die("wo4".mysqli_error($con));


$x="CREATE TABLE USERS(NAME VARCHAR(25),PASS VARCHAR(50))";
if(!mysqli_query($con,$x))
die("wow6".mysqli_error($con));
$x="CREATE TABLE ADMIN(NAME VARCHAR(25),PASS VARCHAR(50))";
if(!mysqli_query($con,$x))
die("wow7".mysqli_error($con));

$Y="INSERT INTO HUB VALUES('CICE-CREATIVITY AND INOVATION CELL IN ELECTRONICS',null,'ATUL SRIVASTAVA',null,'WWW.FACEBOOK.COM/CICEJIIT/?TI=AS','WWW.CICEJIIT.COM','CICE.JIITN@GMAIL.COM',null)";
if(!mysqli_query($con,$Y))
die("wow8".mysqli_error($con));

$Y="INSERT INTO HUB VALUES('UCR-MICRO CONTROLLER BASE SYSTEMS AND ROBOTICS HUB',null,'HEMA N',null,'WWW.FACEBOOK.COM/uCR.JIIT/?TI=AS','UCRJIIT.COM','UCR.JIIT17@GMAIL.COM',null)";
if(!mysqli_query($con,$Y))
die("wow9".mysqli_error($con));
$Y="INSERT INTO HUB VALUES('JEB-JAYPEE ECONOMICS AND BUISNESS HUB',NULL,'MONICA CHOUDHARY',null,'WWW.FACEBOOK.COM/JEB.JIIT/?TI=AS','WWW.JIIT.AC.IN','JEB@GMAIL.COM',null)";
if(!mysqli_query($con,$Y))
die("wow10".mysqli_error($con));
$Y="INSERT INTO HUB VALUES('IOE-ITS OUR EARTH',NULL,'SWATI SHARMA',NULL,'www.facebook.com/ngoitsourearth/?ti=as',NULL,'itsourearth2016@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('DSC-DEVELOPERS STUDENT CLUB',NULL,'MR.MAHENDRA GURVE',NULL,'www.facebook.com/dscjiitnoida/?ti=as',NULL,'gdgjiitnoida@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('GRAFICAS-THE GRAPHICS AND ANIMATION HUB OF JIIT',NULL,NULL,NULL,'www.facebook.com/graficasjiit/?ti=as',NULL,'graficaslab@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('MULTIMEDIA AND GAME DEVELOPMENT HUB OF JIIT',NULL,NULL,NULL,'www.facebook.com/jiit.gamedev/?ti=as',NULL,NULL,NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('THESPIAN CIRCLE- THE THEATRE CLUB OF JIIT',NULL,NULL,NULL,'www.facebook.com/thespiancircle/?ti=as',NULL,'ttc.jiit@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('KALAKRITI',,'','','www.facebook.com/KalakritiJIIT/?ti=as,NULL,NULL,'')";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('SARKASM SOCIETY',,'','','www.facebook.com/sarkasmsociety/','','','')";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('CRESANDO-MUSIC HUB OF JIIT',NULL,NULL,NULL,'www.facebook/jiitmusichub/',NULL,'jaypeemusichub@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('PAROLA',NULL,'PUNEET PAANU',NULL,'www.facebook.com/Parola.LiteraryHub/?ti=as','www.thejoust18.com','parolajiit@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('JPEG-jaypee photo enthusiasts guilt',NULL,NULL,NULL,'www.facebook.com/jiitphotography',NULL,'jiitjpeg123@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('THE PAGE TURNER SOCIETY',,'','','www.facebook.com/ThePageTurnerSociety','pageturnersoc@gmail.com','www.pageturnersociety.ga','')";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('RADIANCE',NULL,NULL,NULL,'www.facebook.com/aisleofvogue/',NULL,'hub.radiance@gmail.com',NULL)";
mysqli_query($con,$Y);
$Y="INSERT INTO HUB VALUES('JYC-JIIT YOUTH CLUB',NULL,'MR.PANKAJ YADAV',NULL,'www.facebook.com/jyc62','www.jiit.ac.in/students/youth.php','jiityouthclub@jiit.ac.in',NULL)";
mysqli_query($con,$Y);


$X="INSERT INTO PERSON VALUES('ANKUR','JYC-JIIT YOUTH CLUB','DIRECTOR PR','CSE',8191818855,NULL)";
mysqli_query($con,$X);
$X="INSERT INTO PERSON VALUES('APOORV','JYC-JIIT YOUTH CLUB','DIRECTOR FINANCE','IT',9811263821,NULL)";
mysqli_query($con,$X);
$X="INSERT INTO PERSON VALUES('DARPAN','JYC-JIIT YOUTH CLUB','DIRECTOR FINANCE','ECE',8130590352,NULL)";
mysqli_query($con,$X);
$X="INSERT INTO PERSON VALUES('RITIK','JYC-JIIT YOUTH CLUB','DIRECTOR OPERATIONS','CSE',9205852138,NULL)";
mysqli_query($con,$X);
$X="INSERT INTO PERSON VALUES('JAYESH','JYC-JIIT YOUTH CLUB','DIRECTOR INTERNAL AFFAIRS','ECE',8373918526,NULL)";
mysqli_query($con,$X);
$X="INSERT INTO PERSON VALUES('SHRUTI','JYC-JIIT YOUTH CLUB','DIRECTOR MEDIA/MARKETING','CSE',9871676510,NULL)";
mysqli_query($con,$X);

$Z="INSERT INTO EVENTS VALUES('EBUILLENCE','JYC-JIIT YOUTH CLUB','2018-09-01','2018-09-01','FREASHER'S PARTY',FALSE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('IMPRESSIONS','JYC-JIIT YOUTH CLUB','2019-02-23','2019-02-24','ANNUAL TECHNO-CULTURAL FEST',TRUE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('EL-ASSISINO','UCR-MICRO CONTROLLER BASE SYSTEMS AND ROBOTICS HUB','2018-08-13','2018-08-14','ROBOTICS EVENT',FALSE)";
mysqli_query($con,$Z);

$Z="INSERT INTO EVENTS VALUES('JOUST','PAROLA','2018-08-23','2018-08-24','LITERARY FEST',FALSE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('JMUN','PAROLA','2019-01-12','2019-01-13','MODEL UNITED NATION CONFERENCE',TRUE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('VIDYUT','CICE-CREATIVITY AND INOVATION CELL IN ELECTRONICS','2018-11-24','2018-11-25','ELECTRONICS FEST WITH YOUTH',TRUE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('HACKFEST','DSC-DEVELOPERS STUDENT CLUB','2018-11-17','2018-11-18','HACKER FEST',FALSE)";
mysqli_query($con,$Z);

$Z="INSERT INTO EVENTS VALUES('CYBER SHRISHTI','JYC-JIIT YOUTH CLUB','2018-04-23','2018-04-24','CULTURAL-CODING FEST',FALSE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('UNPLUGGED','CRESANDO-MUSIC HUB OF JIIT','2018-10-31','2018-10-31','SINGING FEST',FALSE)";
mysqli_query($con,$Z);
$Z="INSERT INTO EVENTS VALUES('MIMEO','MULTIMEDIA AND GAME DEVELOPMENT HUB OF JIIT','2018-09-28','2018-10-08','GAMING FEST',FALSE)";
mysqli_query($con,$Z);


$Q="INSERT INTO FACULTY VALUES('ATUL SRIVASTAVA','CICE-CREATIVITY AND INOVATION CELL IN ELECTRONICS','ECE','ATUL.SRIVASTAVA@JIIT.AC.IN')";
mysqli_query($con,$Q);
$Q="INSERT INTO FACULTY VALUES('HEMA N','UCR-MICRO CONTROLLER BASE SYSTEMS AND ROBOTICS HUB','CSE','HEMA.N@JIIT.AC.IN')";
mysqli_query($con,$Q);

$Q="INSERT INTO FACULTY VALUES('MONICA CHAUDHARY','JEB-JAYPEE ECONOMICS AND BUISNESS HUB','HSS','MONICA.CHAUDHARY@JIIT.AC.IN')";
mysqli_query($con,$Q);
$Q="INSERT INTO FACULTY VALUES('SWATI SHARMA','IOE-ITS OUR EARTH','HSS','SWATI.SHARMA@JIIT.AC.IN')";
mysqli_query($con,$Q);

$Q="INSERT INTO FACULTY VALUES('MR. MAHENDRA GURVE','DSC-DEVELOPERS STUDENT CLUB','CSE','MAHENDRA.GURVE@JIIT.AC.IN')";
mysqli_query($con,$Q);
$Q="INSERT INTO FACULTY VALUES('PANKAJ YADAV','JYC-JIIT YOUTH CLUB','ECE','PANKAJ.YADAV@JIIT.AC.IN')";
mysqli_query($con,$Q);
$Q="INSERT INTO USERS VALUES('ABCCC','ABc123')";
mysqli_query($con,$Q);

?>