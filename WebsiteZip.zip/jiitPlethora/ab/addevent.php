<html>
<head>
    <title>
        Event Details form! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="main.css">
    </head>
    <body>
    <div class="container-contact100">
		<div class="contact100-map" id="google_map" data-map-x="40.722047" data-map-y="-73.986422" data-scrollwhell="0" data-draggable="1"></div>

		<div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Have a great start!
				</span>

				<span class="contact100-form-title-2">
					Tell us more about your event!
				</span>
			</div>

			<form class="contact100-form validate-form" name="form" method="post" action="successaddevent.php" onsubmit="return validation()">
				<div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Event Name&nbsp;&nbsp;:</span>
					<input class="input100" type="text" name="name" placeholder="Enter event name">
					<span class="focus-input100"></span>
				</div>
                <div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Hub Name&nbsp;&nbsp;:</span>
					<select  name="hub">
                        <option value="NULL">-----Select an Option------</option>
                        <?php    
                            include_once('DBConnection.php');
                            $con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);  
                            $sql="select * from hub";
                            $data=mysqli_query($con,$sql);
                            while($row = mysqli_fetch_array($data,MYSQLI_NUM))
                            {
                                echo'<option value="'.$row[0].'">'.$row[0].'</option>';
                            }
                        
                        
                        
                        ?>
                    </select>
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input">
					<span class="label-input100">Start date:</span>
					<input class="input100" type="date" name="startdate" placeholder="Enter start date">
					<span class="focus-input100"></span>
				</div>

                
                <div class="wrap-input100 validate-input">
					<span class="label-input100">End date:</span>
					<input class="input100" type="date" name="enddate" placeholder="Enter end date">
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input100 validate-input" data-validate = "Message is required">
					<span class="label-input100">Details:</span>
					<textarea class="input100" name="detail" placeholder="Enter Details..."></textarea>
					<span class="focus-input100"></span>
				</div>
                
                <div class="wrap-input109 validate-input">
					<span class="label-input100">Ongoing event:</span>
					<input type="radio" name="check" value="1" checked> YES             
                    <input type="radio" name="check" value="0" checked> NO<br>
					<span class="focus-input100"></span>
				</div>
                
				<div class="container-contact100-form-btn">
					<input type="submit" value="Submit" class="contact100-form-btn">
                </div>
					
				
			</form>
		</div>
	</div>
<script type="text/javascript">
function validation()
{

if(document.form.name.value=="")
{
alert("Please Enter Events's Name");
document.form.name.focus();
return false;
}
if(document.form.startdate.value=="")
{
alert("Please Enter Start Date");
document.form.startdate.focus();
return false;
}
if(document.form.enddate.value=="")
{
alert("Please Enter End Date");
document.form.enddate.focus();
return false;
}
if(document.form.detail.value=="")
{
alert("Please Enter Detail");
document.form.detail.focus();
return false;
}
if(document.form.check.value=="")
{
alert("Please Select Yes or No");
document.form.check.focus();
return false;
}    
    
}
</script>
    </body>
</html>