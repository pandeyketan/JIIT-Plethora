<html>
<head>
    <title>
        Admin Login! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="mainadmin.css">
    </head>
    <body>
    <div class="container-contact100">
        <div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Admin Login!
				</span>

			</div>

		<div class="wrap-contact100">
			
        <form class="contact100-form validate-form" name="form" method="post" action="admindetails.php" onsubmit="return validation()">
				<div class="wrap-input100 validate-input" data-validate="Username is required">
					<span class="label-input100">Admin Username&nbsp;&nbsp;:</span>
					<input class="input100" type="text" name="ausername" placeholder="Enter Username..">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Valid password is required">
					<span class="label-input100">Password:</span>
					<input class="input100" type="password" name="adminpass" placeholder="Enter Password..">
					<span class="focus-input100"></span>
				</div>
            <div class="container-contact100-form-btn">
					<input type="submit" value="Login" name='submit' class="contact100-form-btn">
					
				</div>
			</form>
        </div>
        </div>
        </div>
        <script type="text/javascript">
function validation()
{

if(document.form.ausername.value=="")
{
alert("Please Enter Your Username");
document.form.ausername.focus();
return false;
}
if(document.form.adminpass.value=="")
{
alert("Please Enter password");
document.form.adminpass.focus();
return false;
}
    if(document.form.adminpass.value == document.form.ausername.value) {
        alert("Error: Password must be different from Username!");
        document.form.adminpass.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(document.form.adminpass.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        document.form.adminpass.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(document.form.adminpass.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        document.form.adminpass.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(document.form.adminpass.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        document.form.adminpass.focus();
        return false;
      }
}
</script>
    </body>
</html>