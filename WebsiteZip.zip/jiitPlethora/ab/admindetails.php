<html>
<body>
<?php 
 include_once('DBConnection.php');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);   
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{ 
 if (empty($_POST['ausername']) || empty($_POST['adminpass']))  
 { 
 echo 
 "Incorrect username or password"; 
 header("location: adminlogin.html");
 } 
 
 $inUsername = $_POST["ausername"];  
 $inPassword = $_POST["adminpass"]; 
 $abc= "SELECT * FROM admin"; 
 $result=mysqli_query($db,$abc);
$i=0;
while($row=mysqli_fetch_array($result,MYSQLI_NUM))
 {
    $a=$row[0];
    $b=$row[1];
    if($a==$inUsername && $b==$inPassword)
    $i=1;
 }
 
 if ($i==1) 
 {
 header("location:adminwebpage.php");
 
 }
 else
 {
    echo "Incorrect username or password";?>
 
   <a href="adminlogin.php">Login</a>
       <?php 
 } 
 } 
       ?>
 </body> 
 </html>