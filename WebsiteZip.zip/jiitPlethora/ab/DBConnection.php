<?php 
session_start();
define('DB_SERVER', 'localhost'); //database server url and port
define('DB_USERNAME', 'root');  //database server username
define('DB_PASSWORD', $_SESSION["temp2"]); //database server password
define('DB_DATABASE', 'Plethora'); //where profile is the database 
?>