<html>
<head>
    <title>
        Welcome user! 
    </title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="mainadmin.css">
    </head>
    <body>
    <div class="container-contact100">
        <div class="wrap-contact100">
			<div class="contact100-form-title">
				<span class="contact100-form-title-1">
					Welcome user!
				</span>
                
                <span class="contact100-form-title-2">
					Please Enter your sql server password!
				</span>

			</div>

		<div class="wrap-contact100">
			
        <form class="contact100-form validate-form" method="post" action="GOTO.PHP">
				<div class="wrap-input100 validate-input" data-validate="Name is required">
					<span class="label-input100">Server password&nbsp;&nbsp;:</span>
					<input class="input100" type="password" name="serverpass" placeholder="Enter password">
					<span class="focus-input100"></span>
				</div>
				

            <div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						<span>
							Continue to website
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
        </div>
        </div>
        </div>
    </body>
</html>